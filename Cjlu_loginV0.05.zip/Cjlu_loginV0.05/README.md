针对中国计量大学（cjlu）修改了参数的教学区校园网自动登录脚本
大量代码参考https://blog.csdn.net/qq_41797946/article/details/89417722
私自使用部分代码并用自己的破烂代码重置剩余部分


使用办法：



1.1
使用了requests库，如果本地没有库则会报错，
使用安装requests.bat自动安装库



或者在命令行输入
pip install requests
安装库

1.2
点击
初始化用户名密码.bat
输入用户名密码

1.3
确保已经链接到icjlu校园网


1.4
login登录
logout登出